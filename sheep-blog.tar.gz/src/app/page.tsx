import Link from 'next/link'
import { getPostList } from '@/lib/posts'

export default function Home() {
  const posts = getPostList().slice(0, 3)

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-white py-16">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h1 className="text-4xl font-bold text-primary mb-4">
            🐑 大师的学习空间
          </h1>
          <p className="text-lg text-gray-600 mb-8">
            一条普通咸鱼的学习日记与日常感悟
          </p>
          <div className="flex justify-center gap-4">
            <Link
              href="/blog"
              className="px-6 py-3 bg-primary text-white rounded-lg hover:bg-opacity-90 transition-colors"
            >
              浏览文章
            </Link>
          </div>
        </div>
      </section>

      {/* Featured Posts */}
      <section className="py-12">
        <div className="max-w-4xl mx-auto px-4">
          <h2 className="text-2xl font-bold text-primary mb-8 text-center">
            📝 精选文章
          </h2>
          <div className="grid gap-6">
            {posts.map((post) => (
              <Link
                key={post.slug}
                href={`/blog/${post.slug}`}
                className="block bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow p-6 border"
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <span className="text-sm text-gray-500">{post.date}</span>
                    <h3 className="text-xl font-semibold text-primary mt-1 mb-2">
                      {post.title}
                    </h3>
                    <p className="text-gray-600 text-sm line-clamp-2">
                      {post.description}
                    </p>
                  </div>
                  {post.coverImage && (
                    <div className="w-24 h-24 rounded-lg overflow-hidden flex-shrink-0">
                      <img
                        src={post.coverImage}
                        alt={post.title}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  )}
                </div>
              </Link>
            ))}
          </div>
          <div className="text-center mt-8">
            <Link
              href="/blog"
              className="text-primary hover:underline text-sm font-medium"
            >
              查看全部文章 →
            </Link>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-12 bg-white">
        <div className="max-w-4xl mx-auto px-4">
          <h2 className="text-2xl font-bold text-primary mb-6 text-center">
            👋 关于我
          </h2>
          <div className="bg-gray-50 rounded-xl p-8">
            <p className="text-gray-700 leading-relaxed">
              你好！我是一条普通的咸鱼，喜欢学习和探索新知识。
              这个博客记录了我的学习笔记、技术思考和生活感悟。
              希望能在这里与你分享我的成长过程，也期待从你的反馈中获得启发。
            </p>
          </div>
        </div>
      </section>
    </div>
  )
}