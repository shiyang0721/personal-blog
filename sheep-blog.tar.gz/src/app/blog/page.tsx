import Link from 'next/link'
import { getPostList } from '@/lib/posts'

export default function BlogPage() {
  const posts = getPostList()

  return (
    <div className="max-w-4xl mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold text-primary mb-8">📚 所有文章</h1>
      <div className="grid gap-6">
        {posts.map((post) => (
          <Link
            key={post.slug}
            href={`/blog/${post.slug}`}
            className="block bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow p-6 border"
          >
            <div className="flex items-start justify-between gap-4">
              <div className="flex-1">
                <span className="text-sm text-gray-500">{post.date}</span>
                <h3 className="text-xl font-semibold text-primary mt-1 mb-2">
                  {post.title}
                </h3>
                <p className="text-gray-600 text-sm line-clamp-2">
                  {post.description}
                </p>
              </div>
              {post.coverImage && (
                <div className="w-24 h-24 rounded-lg overflow-hidden flex-shrink-0">
                  <img
                    src={post.coverImage}
                    alt={post.title}
                    className="w-full h-full object-cover"
                  />
                </div>
              )}
            </div>
          </Link>
        ))}
      </div>
      {posts.length === 0 && (
        <div className="text-center py-12 text-gray-500">
          <p>暂无文章，敬请期待！</p>
        </div>
      )}
    </div>
  )
}